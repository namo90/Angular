import { Component, OnInit,Input } from '@angular/core';
import { editInorderEventArgs } from '../components/dashboard/dashboard.component';
import { OrderService } from '../services/order.service';

@Component({
  selector: 'app-orderplace',
  templateUrl: './orderplace.component.html',
  styleUrls: ['./orderplace.component.css']
})
export class OrderplaceComponent implements OnInit {
  
  ordercredentails={
    productName:'',
    price:'',
    qty:''
  }

  @Input() childPosts:any[]=[];
  constructor(private orderservice:OrderService) { }

  ngOnInit(): void {

    this.orderservice.$isLoggedin.subscribe((data)=>{
      this.ordercredentails=data;
      console.log("i got ordercredentails",this.ordercredentails);
      
    })
    console.log(".........."+this.childPosts);
   
  }
doget(childPosts:any){
  debugger;
for(let i=0;i<childPosts.length;i++)
console.log(childPosts[i]);
}

         onSubmit()
         {
         // this.doget(this.childPosts);
         debugger;
         console.log("here get data",this.ordercredentails.productName)
          console.log("form is sumbitted");
          if((this.ordercredentails.productName!='' && this.ordercredentails.price !='') && (this.ordercredentails.productName!=null && this.ordercredentails.price !=null) && (this.ordercredentails.qty!=null && this.ordercredentails.qty!=null))
          {
      console.log("We have to sumbit form");
      this.orderservice.saveOrder(this.ordercredentails).subscribe(
        (response:any)=>{
          //success
    console.log("getting order suucess"+" "+response);
    window.location.href="/dashboard"
        },
        (error: any)=>{
          //error
          console.log(error);
      
        }
      )
      //token generate here
          }else{
            console.log("Fields are Empty");
          }
        }
        docheck(){
          debugger;
         console.log("here get data",this.ordercredentails.productName)
        }
        onclose(){
          alert("dddddddddddddddd");
        }
}
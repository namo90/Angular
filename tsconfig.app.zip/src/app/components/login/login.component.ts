import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from 'src/app/services/login-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  logincredentails={
    username:'',
    password:''
  }

  constructor(private loginService:LoginServiceService) { }

  ngOnInit(): void {
  }

  onSubmit(){
    console.log("form is sumbitted");
    if((this.logincredentails.username!='' && this.logincredentails.password !='') && (this.logincredentails.username!=null && this.logincredentails.password !=null))
    {
console.log("We have to sumbit form");
this.loginService.doLogin(this.logincredentails).subscribe(
  (response:any)=>{
    //success
console.log(response.token);
let booleanval=this.loginService.loginUser(response.token)
if(booleanval){
console.log("here geting token value"+" -----"+booleanval)
  window.location.href="/dashboard"
}else{
  console.log("here NOT geting token value"+" -----"+booleanval)
  window.location.href="/login"
}
  },
  error=>{
    //error
    console.log(error);

  }
)
//token generate here
    }else{
      console.log("Fields are Empty");
    }
  }

}

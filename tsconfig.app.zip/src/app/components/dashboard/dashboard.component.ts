import { Component, OnInit,Output,ViewChild,EventEmitter} from '@angular/core';
import { MatSort } from '@angular/material/sort';

import {MatDialog, MatDialogRef,MatDialogConfig} from '@angular/material/dialog';

import { OrderService } from 'src/app/services/order.service';
import { LoginComponent } from '../login/login.component';
import { OrderplaceComponent } from 'src/app/orderplace/orderplace.component';
;
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: number;
}
export interface editInorderEventArgs{
  id:number;
  productName:string;
  price:number;
  qty:number;
  uk:number;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: '{this.order.name}', weight: 100, symbol: 100},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 200},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 300},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 400},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 500},
  {position: 6, name: 'Carbon', weight: 12.0107, symbol: 600},
  {position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 700},
  {position: 8, name: 'Oxygen', weight: 15.9994, symbol: 800},
  {position: 9, name: 'Fluorine', weight: 18.9984, symbol: 900},
  {position: 10, name: 'Neon', weight: 20.1797, symbol: 1000},
];
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  order:any=[]
  searchkey: any
  event:any
  parentdata:any[]=[]
  displayedColumns: string[] = ['demo-position', 'demo-name', 'demo-weight', 'demo-symbol','actions'];
  dataSource = ELEMENT_DATA;
  @ViewChild(MatSort)
  sort: MatSort = new MatSort;
  table: any;
  //@Output('change') change=new EventEmitter();
  constructor(private orderservice:OrderService,
    private dialog:MatDialog) { }

  ngOnInit(): void {
    this.getAllRecord()
    console.log("getting order value "+this.order)
  }
  getAllRecord(){
    debugger;
    this.orderservice.getAllRecord().subscribe(
       order=>{
 console.log(order);
 this.order=order;
     },
     error=>{
 console.log(error);
       }
    )

   }
// add new order 
  addData() {
    const randomElementIndex = Math.floor(Math.random() * ELEMENT_DATA.length);
    this.dataSource.push(ELEMENT_DATA[randomElementIndex]);
    this.table.renderRows();
  }
  onsearchkey(){
    this.searchkey="";
    this.applyfilter();
  }

  applyfilter(){
    debugger;
    this.dataSource.filter= this.searchkey.trim().toLowerCase();
  }
  oncreate(){
    const dialogconfig=new MatDialogConfig();
   // dialogconfig.disableClose=true;
    dialogconfig.autoFocus=true;
    dialogconfig.width="60%";
this.dialog.open(OrderplaceComponent,dialogconfig);
  }
  onedit(event: any){
    debugger;
    
this.orderservice.dashboardserice(event);
     console.log("------"+event);
    // this.parentdata.push(event);
     //console.log("parentdata---"+this.parentdata)
    const dialogconfig=new MatDialogConfig();
   // dialogconfig.disableClose=true;
    dialogconfig.autoFocus=true;
    dialogconfig.width="60%";
  //  window.location.href="/orderplace"
  this.dialog.open(OrderplaceComponent,dialogconfig);
  }
  ondelete(){
    console.log("---");
if(confirm("Are you sure to delete this record ?")){
  
}
  }

  // openConformDialog(){
  //   this.dialog.open(MatDialogConfig,{
  //     width:390px;
  //   })
  // }

}
function MatConfirmDialogComponent(MatConfirmDialogComponent: any) {
  throw new Error('Function not implemented.');
}


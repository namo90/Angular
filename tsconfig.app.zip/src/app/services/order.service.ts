import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable,EventEmitter } from '@angular/core';
import { editInorderEventArgs } from '../components/dashboard/dashboard.component';


@Injectable({
  providedIn: 'root'
})
export class OrderService {
  
  $isLoggedin=new EventEmitter();
  order1:editInorderEventArgs={
    id:0,
    price:0,
    productName:"",
    qty:0,
    uk:0
  };
  url="http://localhost:9090/"
  

  constructor(private http:HttpClient) { }

  saveOrder(ordercredentails:any){
    debugger;
console.log("iside  the  order save ggg")
console.log(this.url + 'save')

return this.http.post(this.url + 'save',ordercredentails)
  }

  dashboardserice(event:any){
    debugger;
    console.log("event data---",event)
    this.order1.id=event.id,
    this.order1.price=event.price,
    this.order1.productName=event.productName,
    this.order1.qty=event.qty,
    this.order1.uk=event.ui_fk
    this.$isLoggedin.emit(this.order1);
    console.log("dashboard edit");
  }

  getAllRecord(){
    debugger;
    console.log("iside  the  order findAllOrders ggg")
    console.log(this.url + 'findAllOrders')
    
    return this.http.get(this.url + 'findAllOrders')
  }
}
